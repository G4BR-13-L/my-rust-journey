use serde::{Deserialize, Serialize};
use sqlx::FromRow;


#[derive(Debug, FromRow, Serialize, Deserialize)]
pub struct Produto {
    pub uuid: uuid::Uuid,
    pub nome: String,
    pub descricao: String,
    pub valor: i32,
    pub data_cadastro: chrono::NaiveDateTime,
    pub ativo: bool,
    pub disponivel: bool,
}

impl FromSql for Produto {
    fn from_sql(_: &tokio_postgres::types::Type, raw: &[u8]) -> Result<Self, Box<dyn std::error::Error + Sync + Send>>{
           let r = postgres_protocol::types::Record::parse(raw, &[]).unwrap();
  
  
        Ok(
                  Self{
                    uuid: Uuid::from_slice(&r[0].as_bytes().unwrap().to_vec()).unwrap(),
                    nome: String::from(std::str::from_utf8(r[1].as_bytes().unwrap()).unwrap()),
                    descricao:String::from(std::str::from_utf8(r[2].as_bytes().unwrap()).unwrap()),
                    valor: r[3].as_i32().unwrap(),
                    data_cadastro: NaiveDateTime::from_timestamp_opt(r[4].as_i64().unwrap(), 0).unwrap(),
                    ativo: r[5].as_bool().unwrap(),
                    disponivel: r[6].as_bool().unwrap(),
  
  
                  }
        )
  
  
  
     }
  
  
      fn accepts(ty: &tokio_postgres::types::Type) -> bool {
         ty == &tokio_postgres::types::Type::RECORD
  
     }
  }