pub fn buscar_todos() -> Vec<String> {
    vec!["Produto A".to_string(), "Produto B".to_string()] // Simula dados do banco
}
