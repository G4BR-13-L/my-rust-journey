#[macro_use] extern crate rocket;

use essencial_backend::produtos::controller::produtos_routes;

#[launch]
fn rocket() -> _ {
    rocket::build().mount("/", produtos_routes())
}
